app.controller('StopsCtrl', function($scope, StopService, $ionicLoading){
  $ionicLoading.show({
    template: 'Зареждане...'
  });
  StopService.get().all().success(function(data){
    $scope.stops = data;
    $ionicLoading.hide()
  });
});
