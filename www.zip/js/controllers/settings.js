app.controller('SettingsCtrl', function($scope, SettingsService, $ionicPopup, $ionicLoading){
  $ionicLoading.show({
    template: 'Зареждане...'
  });
  $scope.bug = {
    title: '',
    email: '',
    content: ''
  };

  $scope.settings = SettingsService.get();
  $ionicLoading.hide();
  $scope.$watchCollection('settings', function(newSettings) {
    SettingsService.set(newSettings);
  });

  $scope.sendBug = function(){
    $scope.bug.title = $scope.bug.title + " : " + $scope.bug.email;
    SettingsService.sendBug($scope.bug).success(function(){
      $ionicPopup.alert({
        title: 'Съобщението е изпратено!',
        template: '<p class="text-center">Съобщението беше изпратено успешно. Благодарим Ви за сигнала.</p>'
      });
      $scope.bug.title = '';
      $scope.bug.email = '';
      $scope.bug.content = '';
    });
  }
})
